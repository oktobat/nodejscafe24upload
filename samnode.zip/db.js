import mysql from 'mysql';
export const db = mysql.createConnection({
    host : 'ysbkey.cafe24app.com',
    user : 'oktobat1235',
    password : 'chamsogum9!',
    database : 'oktobat1235'
})
db.connect()