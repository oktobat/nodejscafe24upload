import express from 'express';
import { list, write, writting, view, edit, editting, remove, pagegroup } from '/home/hosting_users/oktobat1235/apps/oktobat1235_ysbkey/controllers/freeboardController.js'
const freeboardRouter = express.Router();

freeboardRouter.get('/list', list)
freeboardRouter.route('/write').get(write).post(writting)
freeboardRouter.get('/view', view)
freeboardRouter.route('/edit').get(edit).post(editting)
freeboardRouter.get('/remove', remove)
freeboardRouter.get('/pagegroup', pagegroup)

export default freeboardRouter