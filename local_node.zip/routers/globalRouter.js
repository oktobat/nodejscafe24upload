import express from 'express';
import { join, login, loging } from '../controllers/userController.js'

const globalRouter = express.Router();

const handleHome = (req, res) => res.render("index") 

globalRouter.get('/', handleHome)
globalRouter.get('/join', join)
globalRouter.route('/login').get(login).post(loging)


export default globalRouter